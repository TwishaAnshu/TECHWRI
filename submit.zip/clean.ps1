Write-Host "_________________________"
Write-Host "Cleaning up the Directory"
Write-Host "_________________________"
rm *.gch
rm *.exe
Write-Host "_________________________"
Write-Host "Cleanup Complete"
Write-Host "_________________________"